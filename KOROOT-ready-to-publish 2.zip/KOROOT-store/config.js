// Public storefront settings. Change the WhatsApp number here if it changes.
window.KOROOT_CONFIG = {
  brand: "KOROOT",
  whatsappNumber: "201223113777",
  currency: "EGP"
};