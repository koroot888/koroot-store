KOROOT WEBSITE — QUICK PUBLISH GUIDE

WHAT THIS IS
A mobile-friendly static storefront with sample products, category filters, product options, a shopping bag, quantity controls and WhatsApp checkout.

IMPORTANT
The products and prices are DEMO examples. Replace them with your real products before taking orders.
The product visuals are CSS illustrations, not real product photographs.
This version does NOT include a secure admin dashboard, online database, stock syncing, order storage, payment gateway or customer accounts. Do not advertise those features as available yet.
WhatsApp checkout sends the order details to the KOROOT WhatsApp number configured in config.js. The customer and store must confirm stock, delivery and payment manually.

EASIEST WAY TO PUBLISH USING YOUR EXISTING GITHUB REPOSITORY
1. On your iPhone, open https://github.com/koroot888/koroot-store
2. Tap Add file, then Upload files.
3. Upload these four files from this folder:
   index.html
   styles.css
   app.js
   config.js
4. If GitHub asks whether to replace existing files, choose the option to commit/replace the files.
5. Tap Commit changes.
6. Wait a minute, then open:
   https://koroot888.github.io/koroot-store/
7. If you still see the old version, refresh Safari. Sometimes it takes a few minutes to update.

If you cannot find Add file on GitHub mobile:
Open this direct upload page:
https://github.com/koroot888/koroot-store/upload/main

WHATSAPP NUMBER
config.js currently uses 201223113777 (Egypt international format, without the leading 0).
If this is not the correct store number, edit config.js and replace it.

EDITING PRODUCTS
Open app.js in GitHub and find the `const products = [` section near the top. Each product has a name, category, price, colors, sizes and description. Keep the JavaScript punctuation intact. For reliable edits, ask for help rather than deleting other code.

LOGO
No logo file was supplied for this build, so the wordmark is text. The actual logo can be added once it is uploaded.

SECURITY
Never put passwords, private keys, bank details or Supabase service-role keys in these public website files or in a public GitHub repository.
