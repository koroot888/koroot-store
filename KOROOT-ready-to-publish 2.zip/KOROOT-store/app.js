const products = [
  {id:"KR001",name:"CORE OVERSIZED TEE",category:"TOPS",price:650,type:"tee",color:"#d9d6cd",colors:["Black","Off White","Grey"],sizes:["S","M","L","XL"],tag:"BESTSELLER",description:"A relaxed everyday tee with a clean silhouette and easy fit."},
  {id:"KR002",name:"HEAVYWEIGHT HOODIE",category:"TOPS",price:1250,type:"hoodie",color:"#55575b",colors:["Black","Charcoal","Stone"],sizes:["S","M","L","XL"],tag:"NEW DROP",description:"A heavyweight layer made for cooler nights and daily rotation."},
  {id:"KR003",name:"RELAXED CARGO PANTS",category:"BOTTOMS",price:1450,type:"pants",color:"#77745e",colors:["Black","Olive","Sand"],sizes:["S","M","L","XL"],tag:"",description:"Relaxed cargo-inspired trousers with a versatile streetwear fit."},
  {id:"KR004",name:"DAILY CAP",category:"ACCESSORIES",price:450,type:"cap",color:"#33383b",colors:["Black","Navy","Stone"],sizes:["ONE SIZE"],tag:"",description:"A simple everyday cap to finish the fit."},
  {id:"KR005",name:"BOX FIT TEE",category:"TOPS",price:700,type:"tee",color:"#8a8983",colors:["Washed Black","White","Grey"],sizes:["S","M","L","XL"],tag:"",description:"A boxier cut with a little more structure and room."},
  {id:"KR006",name:"UTILITY TRACK PANTS",category:"BOTTOMS",price:1150,type:"pants",color:"#454545",colors:["Black","Grey"],sizes:["S","M","L","XL"],tag:"",description:"An easy, comfortable pair for everyday movement."}
];
const money = n => `${window.KOROOT_CONFIG.currency} ${Number(n).toLocaleString("en-US")}`;
const grid = document.getElementById("productGrid");
const modal = document.getElementById("productModal");
const overlay = document.getElementById("overlay");
const drawer = document.getElementById("cartDrawer");
let selected = null;
let cart = [];

function art(product, extra="") {
  return `<div class="product-art ${extra}" style="--garment:${product.color}"><span class="art-label">KOROOT</span><div class="art-shape ${product.type}"></div>${product.tag ? `<span class="product-tag">${product.tag}</span>` : ""}</div>`;
}
function renderProducts(filter="ALL") {
  grid.innerHTML = products.filter(p => filter==="ALL" || p.category===filter).map(p => `
    <article class="product-card" data-id="${p.id}" tabindex="0" role="button" aria-label="View ${p.name}">
      ${art(p)}
      <div class="product-meta"><div><div class="product-name">${p.name}</div><div class="product-category">${p.category} · UNISEX</div></div><div class="product-price">${money(p.price)}</div></div>
    </article>`).join("");
  grid.querySelectorAll(".product-card").forEach(card => {
    card.addEventListener("click", () => openProduct(card.dataset.id));
    card.addEventListener("keydown", e => { if(e.key==="Enter") openProduct(card.dataset.id); });
  });
}
function openProduct(id) {
  selected = products.find(p=>p.id===id);
  document.getElementById("modalImage").innerHTML = art(selected);
  document.getElementById("modalCategory").textContent = `${selected.category} · KOROOT`;
  document.getElementById("modalName").textContent = selected.name;
  document.getElementById("modalPrice").textContent = money(selected.price);
  document.getElementById("modalDescription").textContent = selected.description;
  document.getElementById("sizeSelect").innerHTML = selected.sizes.map(s=>`<option>${s}</option>`).join("");
  document.getElementById("colorSelect").innerHTML = selected.colors.map(c=>`<option>${c}</option>`).join("");
  document.getElementById("quantitySelect").value = "1";
  modal.classList.add("show"); modal.setAttribute("aria-hidden","false");
}
function closeProduct(){modal.classList.remove("show");modal.setAttribute("aria-hidden","true");}
document.getElementById("closeModal").addEventListener("click",closeProduct);
modal.addEventListener("click",e=>{if(e.target===modal)closeProduct();});
document.getElementById("addToCart").addEventListener("click",()=>{
  const size=document.getElementById("sizeSelect").value;
  const color=document.getElementById("colorSelect").value;
  const qty=Number(document.getElementById("quantitySelect").value);
  const key=`${selected.id}|${size}|${color}`;
  const found=cart.find(i=>i.key===key);
  if(found) found.qty+=qty; else cart.push({key,id:selected.id,name:selected.name,price:selected.price,size,color,qty});
  closeProduct();renderCart();openDrawer();
});
function renderCart(){
  const count=cart.reduce((n,i)=>n+i.qty,0);
  document.getElementById("cartCount").textContent=count;
  document.getElementById("subtotal").textContent=money(cart.reduce((n,i)=>n+i.price*i.qty,0));
  document.getElementById("checkout").disabled=!cart.length;
  document.getElementById("cartItems").innerHTML=cart.length?cart.map(i=>`
    <div class="cart-row"><div class="cart-thumb">KR</div><div><h3>${i.name}</h3><p>${i.color} · ${i.size}</p><div class="cart-controls"><button data-action="minus" data-key="${i.key}">−</button><span>${i.qty}</span><button data-action="plus" data-key="${i.key}">+</button><button class="remove-item" data-action="remove" data-key="${i.key}" aria-label="Remove item">×</button></div></div><strong>${money(i.price*i.qty)}</strong></div>`).join(""):`<p class="empty-cart">Your bag is empty.</p>`;
  document.querySelectorAll("[data-action]").forEach(b=>b.addEventListener("click",()=>{
    const item=cart.find(i=>i.key===b.dataset.key);if(!item)return;
    if(b.dataset.action==="plus")item.qty++;if(b.dataset.action==="minus")item.qty--;if(b.dataset.action==="remove"||item.qty<=0)cart=cart.filter(i=>i.key!==b.dataset.key);
    renderCart();
  }));
}
function openDrawer(){drawer.classList.add("open");drawer.setAttribute("aria-hidden","false");overlay.classList.add("show");}
function closeDrawer(){drawer.classList.remove("open");drawer.setAttribute("aria-hidden","true");overlay.classList.remove("show");}
document.getElementById("openCart").addEventListener("click",openDrawer);
document.getElementById("closeCart").addEventListener("click",closeDrawer);
overlay.addEventListener("click",closeDrawer);
document.getElementById("checkout").addEventListener("click",()=>{
  if(!cart.length)return;
  const lines=cart.map(i=>`• ${i.name} | ${i.color} | Size ${i.size} | Qty ${i.qty} | ${money(i.price*i.qty)}`);
  const total=cart.reduce((n,i)=>n+i.price*i.qty,0);
  const message=`Hello KOROOT! I'd like to place an order:\n\n${lines.join("\n")}\n\nSubtotal: ${money(total)}\n\nPlease confirm availability, delivery fee, address and payment options.`;
  window.open(`https://wa.me/${window.KOROOT_CONFIG.whatsappNumber}?text=${encodeURIComponent(message)}`,"_blank","noopener");
});
document.querySelectorAll(".filter").forEach(b=>b.addEventListener("click",()=>{
  document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));b.classList.add("active");renderProducts(b.dataset.filter);
}));
renderProducts();renderCart();